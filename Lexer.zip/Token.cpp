#include "Token.h"

void Token::makeToken(const string& inputString) {
    for (size_t i = 0; i < inputString.size(); i++) {
        if (inputString.at(i) == '\n') {
            if (tokenString.empty()) {
                if (i != inputString.size() - 1) {
                    tokenLine++;
                }
            }
            else if ((tokenString.at(0) != '#' && tokenString.at(1) != '|') || (tokenString.at(0) != '\'')) {
                continue;
            }
            if (i + 1 == inputString.size()) {
                break;
            }
        }
        if (tokenString.empty() && (inputString.at(i) != '\'' && inputString.at(i) != '#')) {
            if (inputString.at(i) == '\n' || inputString.at(i) == '\t' || inputString.at(i) == ' ') {
                continue;
            }
        }

        tokenString.push_back(inputString.at(i));

        if (tokenString == "Queries" && !isalpha(inputString.at(i+1))) {
            tempString = tokenString;
            tokenString.clear();
            tokenType = QUERIES;
            allTokens.push_back(toStringToken());
            countTokens++;
        } else if (tokenString == "Queries" && isalpha(inputString.at(i+1))) {
            continue;
        } else if (tokenString == "Rules" && !isalpha(inputString.at(i+1))) {
            tempString = tokenString;
            tokenString.clear();
            tokenType = RULES;
            allTokens.push_back(toStringToken());
            countTokens++;
        } else if (tokenString == "Rules" && isalpha(inputString.at(i+1))) {
            continue;
        } else if (tokenString == "Facts" && !isalpha(inputString.at(i+1))) {
            tempString = tokenString;
            tokenString.clear();
            tokenType = FACTS;
            allTokens.push_back(toStringToken());
            countTokens++;
        } else if (tokenString == "Facts" && isalpha(inputString.at(i+1))) {
            continue;
        } else if (tokenString == "Schemes" && !isalpha(inputString.at(i+1))) {
            tempString = tokenString;
            tokenString.clear();
            tokenType = SCHEMES;
            allTokens.push_back(toStringToken());
            countTokens++;
        } else if (tokenString == "Schemes" && isalpha(inputString.at(i+1))) {
            continue;
        } else if (tokenString == ":") {
            if (inputString.at(i+1) == '-') {
                continue;
            }
            tempString = tokenString;
            tokenString.clear();
            tokenType = COLON;
            allTokens.push_back(toStringToken());
            countTokens++;
        } else if (tokenString == ":-") {
            tempString = tokenString;
            tokenString.clear();
            tokenType = COLON_DASH;
            allTokens.push_back(toStringToken());
            countTokens++;
        } else if ((tokenString != "Queries" && tokenString != "Rules" && tokenString != "Facts" &&
                    tokenString != "Schemes") &&
                   (isalpha(tokenString.at(0)) && !isalpha(inputString.at(i+1)) && !isdigit(inputString.at(i+1)) && inputString.at(i+1) != '\'')) {
            tempString = tokenString;
            tokenString.clear();
            tokenType = ID;
            allTokens.push_back(toStringToken());
            countTokens++;
        } else if (tokenString == "(") {
            tempString = tokenString;
            tokenString.clear();
            tokenType = LEFT_PAREN;
            allTokens.push_back(toStringToken());
            countTokens++;
        } else if (tokenString == "'") {
            continue;
        } else if (tokenString.at(0) == '\'' && tokenString.at(tokenString.size() - 1) == '\'') {
            if (i + 1 != inputString.size()) {
                if (inputString.at(i + 1) == '\'') {
                    continue;
                }
            }
            if (i + 1 != inputString.size()) {
                if (inputString.at(i + 1) != '\'') {
                    tempString = tokenString;
                    tokenString.clear();
                    tokenType = STRING;
                    allTokens.push_back(toStringToken());
                    countTokens++;
                }
            }
        } else if (tokenString == ",") {
            tempString = tokenString;
            tokenString.clear();
            tokenType = COMMA;
            allTokens.push_back(toStringToken());
            countTokens++;
        } else if (tokenString == ".") {
            tempString = tokenString;
            tokenString.clear();
            tokenType = PERIOD;
            allTokens.push_back(toStringToken());
            countTokens++;
        } else if (tokenString == "?") {
            tempString = tokenString;
            tokenString.clear();
            tokenType = Q_MARK;
            allTokens.push_back(toStringToken());
            countTokens++;
        } else if (tokenString == ")") {
            tempString = tokenString;
            tokenString.clear();
            tokenType = RIGHT_PAREN;
            allTokens.push_back(toStringToken());
            countTokens++;
        } else if (tokenString == "*") {
            tempString = tokenString;
            tokenString.clear();
            tokenType = MULTIPLY;
            allTokens.push_back(toStringToken());
            countTokens++;
        } else if (tokenString == "+") {
            tempString = tokenString;
            tokenString.clear();
            tokenType = ADD;
            allTokens.push_back(toStringToken());
            countTokens++;
        } else if (tokenString == "#") {//TODO: COMMENTS
            continue;
        } else if (tokenString.at(0) == '#') {
            if (tokenString.at(1) == '|') {
                if (tokenString.at(tokenString.size() - 2) == '|' &&
                    tokenString.at(tokenString.size() - 1) == '#') {
                    tempString = tokenString;
                    tokenString.clear();
                    tokenType = COMMENT;
                    allTokens.push_back(toStringToken());
                    countTokens++;
                } else {
                    continue;
                }
            } else if (inputString.at(i+1) == '\n' || i + 1 == inputString.size()) {
                tempString = tokenString;
                tokenString.clear();
                tokenType = COMMENT;
                allTokens.push_back(toStringToken());
                countTokens++;
            }
        } else if (((tokenString.at(0) == '#' && tokenString.at(1) == '|') || tokenString.at(0) == '\'') && i + 1 == inputString.size()) {
            tempString = tokenString;
            tokenString.clear();
            tokenType = UNDEFINED;
            allTokens.push_back(toStringToken());
            countTokens++;
        }
        else if (!isalpha(inputString.at(i)) && (!isdigit(inputString.at(i))) && tokenString.at(0) != '#' && tokenString.at(0) != '\'') {
            tempString = tokenString;
            tokenString.clear();
            tokenType = UNDEFINED;
            allTokens.push_back(toStringToken());
            countTokens++;
        }
    }
    tempString = "";
    tokenType = E_O_F;
    countTokens++;
    tokenLine++;
    allTokens.push_back(toStringToken());
}

string Token::toStringAllTokens() const {
    ostringstream outputString;
    for (size_t i = 0; i < allTokens.size(); i++) {
        outputString << allTokens.at(i) << endl;
    }
    stringstream ss;
    ss << countTokens;
    string numberString = ss.str();
    outputString << "Total Tokens = " << numberString << endl;
    return outputString.str();
}

string Token::toStringToken() const {
    ostringstream outputString;

    switch(tokenType) {
        case QUERIES:
            outputString << "(QUERIES," << "\"" << tempString << "\"" << "," << tokenLine << ")";
            return outputString.str();
        case COMMA:
            outputString << "(COMMA," << "\"" << tempString << "\"" << "," << tokenLine << ")";
            return outputString.str();
        case PERIOD:
            outputString << "(PERIOD," << "\"" << tempString << "\"" << "," << tokenLine << ")";
            return outputString.str();
        case Q_MARK:
            outputString << "(Q_MARK," << "\"" << tempString << "\"" << "," << tokenLine << ")";
            return outputString.str();
        case LEFT_PAREN:
            outputString << "(LEFT_PAREN," << "\"" << tempString << "\"" << "," << tokenLine << ")";
            return outputString.str();
        case RIGHT_PAREN:
            outputString << "(RIGHT_PAREN," << "\"" << tempString << "\"" << "," << tokenLine << ")";
            return outputString.str();
        case COLON:
            outputString << "(COLON," << "\"" << tempString << "\"" << "," << tokenLine << ")";
            return outputString.str();
        case COLON_DASH:
            outputString << "(COLON_DASH," << "\"" << tempString << "\"" << "," << tokenLine << ")";
            return outputString.str();
        case MULTIPLY:
            outputString << "(MULTIPLY," << "\"" << tempString << "\"" << "," << tokenLine << ")";
            return outputString.str();
        case ADD:
            outputString << "(ADD," << "\"" << tempString << "\"" << "," << tokenLine << ")";
            return outputString.str();
        case SCHEMES:
            outputString << "(SCHEMES," << "\"" << tempString << "\"" << "," << tokenLine << ")";
            return outputString.str();
        case FACTS:
            outputString << "(FACTS," << "\"" << tempString << "\"" << "," << tokenLine << ")";
            return outputString.str();
        case RULES:
            outputString << "(RULES," << "\"" << tempString << "\"" << "," << tokenLine << ")";
            return outputString.str();
        case ID:
            outputString << "(ID," << "\"" << tempString << "\"" << "," << tokenLine << ")";
            return outputString.str();
        case STRING:
            outputString << "(STRING," << "\"" << tempString << "\"" << "," << tokenLine << ")";
            return outputString.str();
        case COMMENT:
            outputString << "(COMMENT," << "\"" << tempString << "\"" << "," << tokenLine << ")";
            return outputString.str();
        case UNDEFINED:
            outputString << "(UNDEFINED," << "\"" << tempString << "\"" << "," << tokenLine << ")";
            return outputString.str();
        case E_O_F:
            outputString << "(EOF," << "\"" << tempString << "\"" << "," << tokenLine << ")";
            return outputString.str();
    }
    return outputString.str();
}
